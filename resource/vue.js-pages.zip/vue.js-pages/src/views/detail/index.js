import Vue from 'vue'
import Detail from './detail.vue'

/* eslint-disable no-new */
new Vue({
  el: '#detail',
  template: '<Detail></Detail>',
  components: {
    Detail
  }
})
