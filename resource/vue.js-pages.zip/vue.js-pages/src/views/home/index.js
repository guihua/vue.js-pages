import Vue from 'vue'
import List from './company.vue'

/* eslint-disable no-new */
new Vue({
  el: '#root',
  template: '<List></List>',
  components: {
    List
  }
})
